Thank you for downloading a copy of Rock Paper Scissors for python
This Python Program is based off of rock paper scissors and is intended to run like the original Rock Paper Scissors game - the only difference being that this version is written with Python and can therefore be run and downloaded for free!

To install:
1.Unzip/Extract the files in the folder to your computer.
2.If you do not have python please install the version 2.7.2 from http://www.python.org/download
3.Open the file Rock Paper Scissors Game.
4.Enjoy!